<?php 
	if ($()) {
		# code...
	}
 ?>