// 创建XMLHttpRequest对象
function GetXmlHttpObject() {
  var xmlHttp=null;
  try {
   // Firefox, Opera 8.0+, Safari
   xmlHttp = new XMLHttpRequest();
  } catch (e) {
   // Internet Explorer
    try {
      xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
      xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
  return xmlHttp;
}

function getArticleList(listID) {
  // 创建xhr对象
  var xmlHttp = GetXmlHttpObject();
  if(xmlHttp == null) {
    alert ("Browser does not support HTTP Request");
    return;
  }
  // 填写要获取的内容
  var url = "uri";
  url = url + "?q=" + listID;
  url = url + "&sid=" + Math.random();
  xmlHttp.onreadystatechange = function () {
    if (xmlHttp.readyState == 4 || xmlHttp.readyState == "complete") {
      var str = '';
      $.getJSON(url, function(result, textStatus) {
        $.each(result, function(name, value){
          str += '<a href="' + result[name].href + '" class="weui_media_box weui_media_appmsg"><div class="weui_media_hd">';
          str += '<img class="weui_media_appmsg_thumb" src="' + result[name].src + '" alt=""></div><div class="weui_media_bd">';
          str += '<p class="weui_media_desc">' + result[name].title + '</p></div></a>';
        });
        // 插入到后面的内容列表
        $(listID).append(str);
      });
    }
  };
  xmlHttp.open("GET", url, true);
  xmlHttp.send(null);
}
