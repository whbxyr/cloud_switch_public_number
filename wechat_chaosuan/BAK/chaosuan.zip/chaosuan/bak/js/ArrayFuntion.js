/**
 * ES3 实现 ES5 的数组的map方法
 * @type {array}
 */
var map = Array.prototype.map 
/**
 * @param  {array}    a  
 * @param  {function} f
 * @return {array}    
 */
          ? function (a, f) { return a.map(f); }   //ES5
          : function (a, f) {                      //ES3
          	 var results = [];
             for (var i = 0; i < a.length; i++) {
             	if (i in a ) {
             		results[i] = f.call(null, a[i], i, a);
             	}
             }
             return results;
          }

/**
 * 实现reduce方法
 * @type {[type]}
 */
var reduce = Array.prototype.reduce
          ? function (a, f, initial) {          //ES5
          	if (arguments.length > 2) {
          		return a.reduce(f, initial);
          	} else {
          		return a.reduce(f);
          	}
          }
         : function (a, f, initial) {          //ES3
         	var i = 0, len = a.length, accumulator;

         	if (arguments.length > 2) {
         		accumulator = initial;
         	} else {
         		if (len == 0) {
         			throw TypeError();
         		}
         		while (i < len) {
         			if (i in a) {
         				accumulator = a[i++];
         				break;
         			}
         			else i++;
         		}
         		if (i == len) {
         			throw TypeError();
         		}
         	}

         	while (i < len) {
         		if (i in a) {
         			accumulator = f.call(undefined, accumulator, a[i], i, a);
         			i++;
         		}
         	}

         	return accumulator;
         }
