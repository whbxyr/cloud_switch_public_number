/**
 * 获取文章列表
 * listObj object 
 */
function downArticles(listObj) {
    // 页数
    listObj.currentPage ++;
    // 更新年份
    $('#' + listObj.id + ' .year-place').load('./files/year.json',
                            {
                                'listID': listObj.listid,
                                'pageNum': listObj.currentPage,
                                'toGet': 'year'
                            },function () {
                                listObj.year = $('#' + listObj.id + ' .year-place').html();
                            });
    // 更新文章列表
    $.ajax({
        type: "post",
        url: './files/' + listObj.id + ".json",
        data: { listId: listObj.id, year: listObj.year, num: listObj.num, maxSum: 4},
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                changeLists(data, listObj.id);
                listObj.num += data.length;
                // console.log("Lists success");
                // console.log(listObj.num);
            } else {
                listObj.true = false;  //分页
            }
        },
        // error: function () {
        //     console.log("Lists error");
        // }
    });

    // 更新侧边栏
    $.ajax({
        type: "post",
        url: './files/' + listObj.id + "_new.json",
        data: {listId: listObj.id, newArticleNum: 4},
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                changeSidebar(data, listObj.id);
                // console.log("Sidebar success");
            } else {
                listObj.true = false;  //分页
            }
        },
        // error: function () {
        //     console.log("Sidebar error");
        // }
    })
}

/**
 * 改变页面主内容
 */
function changeLists(data, listId) {
    // 包裹层数，2篇文章一个包裹层
    var str = '', length = data.length, k = 0;
    for(var i  = 0, len = Math.ceil(data.length / 2); i < len; i += 1) {
        str += '<div class="article-row">';
        for(var j = 0; j < 2 && length > 0; j += 1) {
            length --;
            str += '<article class="article article-summary"><div class="article-summary-inner"><a href="' 
                    + data[k].url + '" class="thumbnail"><span style="background-image:url('
                    + data[k].bgimage + ')" class="thumbnail-image"></span></a><div class="article-meta"><p class="category"></p><p class="date"><time datetime="' 
                    + data[k].datatime + '" itemprop="' + data[k].itemprop +'">' 
                    + data[k].date + '</time></p></div><h1 class="article-title" itemprop="name"><a href="">' 
                    + data[k].title +'</a></h1></div></article>';
            k += 1;
        }
        str += '</div>';
    }
    $('#' + listId + ' .archives').html(str);
    // console.log(str);
}

/**
 * 改变页面侧边栏
 */
function changeSidebar(data, listId) {
    var str = '';
    for(var i = 0, length = data.length; i < length; i += 1) {
        str += '<li><div class="item-thumbnail"><a href="'
                + data[i].url + '" class="thumbnail"><span class="thumbnail-image">'
                + '</span></a></div><div class="item-inner"><p class="item-category"></p>'
                + '<p class="item-title"><a href="' 
                + data[i].url + '" class="title">' + data[i].title 
                + '</a></p><p class="item-date"><time datetime="' 
                + data[i].datatime + '" itemprop="' + data[i].itemprop + '">' 
                + data[i].date + '</time></p></div></li>';
    }
    $('#' + listId + ' #recent-post').html(str);

}